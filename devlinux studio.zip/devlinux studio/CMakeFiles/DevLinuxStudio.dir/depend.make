# Empty dependencies file for DevLinuxStudio.
# This may be replaced when dependencies are built.
