file(REMOVE_RECURSE
  "CMakeFiles/DevLinuxStudio.dir/TextEditor.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/TextEditor.cpp.o.d"
  "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_glfw.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_glfw.cpp.o.d"
  "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_opengl3.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_opengl3.cpp.o.d"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui.cpp.o.d"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_draw.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_draw.cpp.o.d"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_tables.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_tables.cpp.o.d"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_widgets.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_widgets.cpp.o.d"
  "CMakeFiles/DevLinuxStudio.dir/main.cpp.o"
  "CMakeFiles/DevLinuxStudio.dir/main.cpp.o.d"
  "DevLinuxStudio"
  "DevLinuxStudio.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/DevLinuxStudio.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
