
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/TextEditor.cpp" "CMakeFiles/DevLinuxStudio.dir/TextEditor.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/TextEditor.cpp.o.d"
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/imgui/backends/imgui_impl_glfw.cpp" "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_glfw.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_glfw.cpp.o.d"
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/imgui/backends/imgui_impl_opengl3.cpp" "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_opengl3.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/imgui/backends/imgui_impl_opengl3.cpp.o.d"
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/imgui/imgui.cpp" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui.cpp.o.d"
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/imgui/imgui_draw.cpp" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_draw.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_draw.cpp.o.d"
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/imgui/imgui_tables.cpp" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_tables.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_tables.cpp.o.d"
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/imgui/imgui_widgets.cpp" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_widgets.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/imgui/imgui_widgets.cpp.o.d"
  "/home/mxaxrxixo/Desktop/desktop dev apps/1-dev tools/XDevLinuxStudio/main.cpp" "CMakeFiles/DevLinuxStudio.dir/main.cpp.o" "gcc" "CMakeFiles/DevLinuxStudio.dir/main.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
